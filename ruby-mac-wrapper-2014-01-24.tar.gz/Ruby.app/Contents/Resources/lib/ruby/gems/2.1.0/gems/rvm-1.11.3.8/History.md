# 1.11.3.8 / 2013-05-29

* correctly refers to :rvm_path config, merged #13

# 1.11.3.7 / 2013-03-31

* add return value to RVM.use, merged #12

# 1.11.3.6 / 2013-01-24

* Add :rvm_by_path option to #rvm method to invoke rvm with full path, merged #11

# 1.11.3.5 / 2012-07-02

* fix gemset use, fix #5, merged #9

# 1.11.3.4 / 2012-06-18

* Fix bug that prevented /etc/rvmrc from being used, merged #7
* Added a license to play nicely with pivotal/LicenseFinder, merged #4

# 1.11.3.3 / 2012-03-27

* do not use UTF in gemspec

# 1.11.3.2 / 2012-03-27

* add example to the doc, update gemspec

# 1.11.3.1 / 2012-03-26

* Ported RVM Gem Library into it's own repository from the main RVM
  repostitory. ( https://github.com/wayneeseguin/rvm-gem )
