module RubygemsBundler
  VERSION = "1.4.2"
end
