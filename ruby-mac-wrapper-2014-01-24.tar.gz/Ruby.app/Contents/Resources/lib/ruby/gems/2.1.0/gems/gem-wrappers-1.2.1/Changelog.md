# Changelog

## 1.2.1
date: 2013-12-22

- Add `ri`, `rdoc` and `testrb` to the list of default ruby executables

## 1.2.0
date: 2013-12-22

- Add support for generating scripts wrappers
- Improved gems searching and tests

## 1.1.0
date: 2013-12-20

- Add functionality to uninstall wrappers when gem is uninstalled

## 1.0.0
date: 2013-12-19

- Stable version released
