module ExecutableHooks
  VERSION = "1.2.6"
end
