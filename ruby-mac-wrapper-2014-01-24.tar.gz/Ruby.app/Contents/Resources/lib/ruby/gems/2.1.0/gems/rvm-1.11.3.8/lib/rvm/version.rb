module RVM
  Version = "1.11.3.8"
end
